---
type: questions
status: open
updated: 2026-10-26
sources:
  - "[[Sources/Pre-proposal]]"
  - "[[Sources/Baluan Survey Tally]]"
---

# Open Questions

These gaps come from reviewing the proposal and later supplied sources. They are not requests to change its scope. Record answers and their evidence in [[Decisions/Decision Register|Decision Register]], update the owning note, and mark the relevant question resolved.

| ID | Priority | Question | Owner note | Status |
| --- | --- | --- | --- | --- |
| Q-01 | Before device targeting | Is support limited to Android 10–14, or does it extend to later Android releases? What devices must be validated? | [[Project/Scope and Requirements|Scope and Requirements]] | Open |
| Q-02 | Before scoring | What metrics award each star, what permits level completion, and does any star threshold affect unlocking? | [[Project/Scope and Requirements|Scope and Requirements]] | Open |
| Q-03 | Before progression | What is the episode order and initially unlocked episode? Does episode completion require all 15 levels? Are the stated counts separate playable levels or variations of shared content? | [[Project/Game Flow|Game Flow]] | Open |
| Q-04 | Before lesson production | Which curriculum competencies, rocks, minerals, and landform associations will be taught, and who validates the content? | [[Project/Learning Content|Learning Content]] | Open |
| Q-05 | Before study evaluation | What study design, participants, instruments, duration, analysis, and school/consent arrangements will substantiate the intended knowledge benefit? | [[Project/Research and Evaluation|Research and Evaluation]] | Open |
| Q-06 | Before gameplay completion | What happens on timeout, falling into a pit, encountering traps, retrying, pausing, or leaving a level? Which settings and tutorial behavior are required? | [[Project/Game Flow|Game Flow]] | Open |
| Q-07 | Before save implementation | How are replayed stars and collectibles aggregated? Is there one local player profile or several? How do name entry, reset, interrupted saves, and reinstalls behave? | [[Project/Technical Baseline|Technical Baseline]] | Open |
| Q-08 | Before treating scope as approved | Is this the current adviser-approved proposal? Is there a newer version or written approval that should supersede this baseline? | [[Sources/Pre-proposal|Pre-proposal provenance]] | Open |
| Q-09 | Before generalizing survey findings | When was the Baluan survey administered, which grades and respondent groups were included, how were respondents selected, and where are the administered instruments and underlying records? The tally alone does not supply these details. | [[Sources/Baluan Survey Tally|Survey provenance]] | Open |
| Q-10 | Before citing topic totals | Why does the mathematics-topic table report 14 when its listed frequencies sum to 13? Are the topic frequencies parent responses, teacher responses, or a combination, and how were multiple mentions coded? | [[Sources/Baluan Survey Tally#Data checks|Survey data checks]] | Open |

No answers have been inferred from the Unity project. The confirmed user instruction to make this vault authoritative for project knowledge is recorded separately as D-001.
