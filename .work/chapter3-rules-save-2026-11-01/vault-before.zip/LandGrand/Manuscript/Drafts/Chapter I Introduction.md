---
type: manuscript-draft
status: proposed
updated: 2026-10-30
revision: 9
sources:
  - "[[Sources/Chapter I Final User Draft 2026-10-30]]"
  - "[[Sources/Researcher Observation - Rock and Mineral Samples 2026-10-30]]"
  - "[[Manuscript/Chapter 1-3 Writing Guide]]"
  - "[[Project/Scope and Requirements]]"
  - "[[Sources/Baluan Survey CSV Records]]"
  - "[[Sources/Project Clarifications 2026-10-26]]"
  - "[[Sources/UNESCO GEM 2023 Technology]]"
  - "[[Sources/DepEd Distance Learning Strategies 2020]]"
  - "[[Sources/PHIVOLCS Sarangani Earthquake 2026]]"
---

# Chapter I Introduction

> Revision 9, corrected review copy. [[Manuscript/Drafts/Land Grand - Chapter I - Revised - v9.docx|Open the current Word copy]]. Based on the user's final-named source under D-020. Includes a three-entry bibliography, restored scope details and seven local review comments. Problem 4 is attributed to the researcher's reported observation under D-021; its date and sample details remain pending. Nine pages were inspected; Context spans pages 1–4 and Bibliography is on page 9. The planned November–December 2026 window retains D-015's contextual year distinction. [[Manuscript/Chapter I Revision Notes|Revision notes]] own the remaining checks. Original and earlier Word versions are preserved.

This chapter introduces Land Grand, a proposed educational game for Grade 5 learners at Baluan Elementary School. It explains the project context, purpose, objectives, scope, and limitations.

## Project Context

This section explains the background and learning concerns that guide the development of Land Grand. It begins with educational technology worldwide, then discusses home learning in the Philippines and the needs reported at Baluan Elementary School.

Educational technology should respond to the needs of learners and teachers. UNESCO's 2023 Global Education Monitoring Report recommends choosing technology that fits local conditions and supports fair access to learning. It also stresses the need for evidence and resources that can be maintained over time (UNESCO, 2023). These points guide the proposed use of a learning game at Baluan Elementary School.

The value of a digital resource depends on how it supports the lesson. In Land Grand, short explanations will be linked to activities involving landforms, rocks, and minerals. Learners will explore a game environment, collect items, and read descriptions related to the lesson. The project will examine this approach as an additional learning resource rather than assume that playing a game guarantees better understanding.

In the Philippines, printed and digital modules were among the learning options used during the COVID-19 period. The Department of Education's 2020 guidance allowed supporting materials, including interactive electronic resources, alongside distance-learning activities. It also described the role of adults who assist learners at home (Department of Education, 2020, Appendix A and Appendix B). This experience provides a national background for developing resources that support learning beyond the classroom.

Disasters can also affect the arrangements needed for learning at home. DOST-PHIVOLCS recorded a magnitude 7.8 earthquake offshore Sarangani on June 8, 2026 (DOST-PHIVOLCS, 2026). As of October 2026, Baluan Elementary School holds face-to-face classes. Modular learning is considered an option if another disaster interrupts classroom instruction. Land Grand is therefore intended to support home study during regular schooling and possible disruptions.

An initial survey at Baluan Elementary School on July 7, 2026 gathered responses from 20 parents and 20 teachers. Parent responses covered Grades 4–6, while teacher responses covered Kindergarten and Grades 3–6. The parent group was available during the scheduled parents' orientation meeting. The researcher reported using random selection.

Parent responses showed difficulty explaining lessons in printed modules. In the parent group, 85% reported this concern. This finding supports considering additional explanations for home study. Land Grand will focus those explanations on the selected Science topics.

Teacher responses reflected mixed views about modular learning. Responses included doubts about how well it helped learners understand lessons. Other responses were positive or uncertain. The project therefore proposes additional activities alongside printed materials and teacher guidance.

Survey responses identified landforms, rocks, and minerals among the Science topics considered difficult. These reports provide a basis for selecting content for the game. The final lessons and selected items will be reviewed for scientific accuracy and Grade 5 Science curriculum alignment.

The researcher observed limited rock and mineral samples for classroom demonstrations. Digital illustrations can provide additional examples when specimens are unavailable. Land Grand will combine these illustrations with names and descriptions of collected items. These examples will serve as supplementary visual material for the selected Science topics.

Most parents and teachers believed that a mobile game could support printed modules. However, some parents were unsure or unwilling to allow its use. Reported access to a smartphone, tablet, or computer also does not confirm access to a compatible Android device. These differences support offering the game as an additional resource while retaining printed materials and teacher guidance.

The survey describes the views of parents and teachers from several grades. It does not directly measure pupil achievement or the effectiveness of Land Grand. The Grade 5 target of the game is separate from the survey population. The findings provide local background for the proposed learning resource.

The project focuses on the following reported problems:

1. Parents reported difficulty explaining lessons in printed modules.

2. Teacher responses raised concerns about the effectiveness of modular learning.

3. Survey responses identified landforms, rocks, and minerals as difficult Science topics.

4. The researcher observed limited rock and mineral samples for classroom demonstrations.

These concerns support developing Land Grand while regular classes continue, before another disruption increases reliance on home study. The game will bring short lessons, item descriptions, and review activities into an offline resource. Learners can return to these activities across separate play sessions. This approach is intended to support home learning alongside the materials and guidance already provided by the school.

## Purpose and Description of the Project

This section explains the purpose of Land Grand and describes its main learning activities. It shows how the proposed game will support Grade 5 learners alongside printed learning materials.

The game aims to support knowledge of landforms, rocks, and minerals through guided exploration. It will contain four episodes covering Mountains, Hills, Plains, and Plateaus. Before each level, learners will read a short lesson about the landform and selected rocks and minerals.

During play, learners will move and jump with an explorer character in a two-dimensional environment. They will collect rocks and minerals and read each item's name and description. Obstacles and other challenges will form part of the exploration activities.

After a level, learners will see the collected items, a short review, and up to three gameplay stars. They can replay completed content or continue to the next available level. The game will save progress on the device for later sessions.

The project combines short explanations, interactive practice, and digital examples in one offline application. Digital examples will supplement physical specimens as additional visual material. The game is intended to support printed materials and teacher guidance during home study.

## Objectives of the Project

This section presents the general and specific objectives of Land Grand. The specific objectives follow the same order as the project concerns and describe features that can be built and checked.

The general objective is to develop Land Grand, an offline Android exploration game for Grade 5 learners at Baluan Elementary School. It aims to support their knowledge of landforms, rocks, and minerals. Project completion is planned for November–December 2026.

The specific objectives are to complete the following within the planned period:

1. Provide short Science lessons before each level to help parents explain the selected topics during home study.

2. Add interactive exploration and reviews after each level to support learning alongside printed Science modules.

3. Develop four episodes covering Mountains, Hills, Plains, and Plateaus, with selected rock and mineral content.

4. Present digital illustrations of selected rocks and minerals with names and short descriptions.

## Scope and Limitations of the Project

This section describes the coverage and boundaries of the Land Grand project. It explains what the game includes and the limits of its use and the survey findings.

### Scope

This section outlines the learners, content, game activities, and technical requirements included in Land Grand.

The proposed game is for Grade 5 learners at Baluan Elementary School. Development will use Unity and C#. Piskel and Clip Studio Paint will be used for graphical assets. The application will include the following features:

- The game will support single-player mode only.

- Four episodes will cover Mountains, Hills, Plains, and Plateaus. Each episode will include selected related rocks and minerals.

- Each episode will have 3 Easy, 5 Normal, and 7 Hard levels. The planned total is 60 levels.

- A short lesson will appear before each level. Collected items will have digital illustrations, names, and short descriptions. A review will follow each completed level.

- The game will use two-dimensional (2D) graphics, large touch buttons, background music, and sound effects.

- Players will move, jump, and collect items. Challenges will include obstacles, traps, pitfalls, and time limits.

- Players will progress through difficulty modes and episodes. They can replay levels, continue to available levels, and view episode summaries. A final screen will appear after completing all episodes.

- Players may earn up to three stars per level. Star and completion rules will be defined during development.

- The Main Menu will offer Play, Settings, Tutorial, and Exit. Players will select unlocked episodes through the Landform Map.

- The game will automatically save and load data on the device. Saved data will include the player's name, unlocked episodes, completed levels, stars, and collected items.

- The game will work offline on Android phones and tablets running Android 10 and above. Minimum targets are 2 GB RAM and 300 MB free storage. These targets still require device testing. 

Development will test one complete level before expanding to all 60 levels. Checks will cover content, controls, item descriptions, review, local saving, and device performance.

### Limitations

This section explains the limits of the game and how the survey findings should be understood. It identifies the boundaries of the project's learners, content, and offline use.

- The game is intended for Grade 5 learners at Baluan Elementary School. The survey includes parent and teacher responses from several grades. Overall results should not be presented as findings for Grade 5 alone.

- Content will cover the four landforms and selected rocks and minerals. It will undergo scientific and curriculum review before use.

- The game will not include multiplayer, online accounts, online features, cloud storage, websites, or an administrator panel.

- Saved progress stays on the device used. The game does not provide central teacher monitoring or shared learner records.

- The game will exclude separate quiz screens, GPS functions, and real-world scanning.

- The game is designed to support printed materials and teacher guidance. Stars, collected items, and completed levels record gameplay. They do not measure learning gains.

- Digital illustrations provide additional visual support. They do not provide physical samples or hands-on examination of real rocks and minerals.

- The initial survey records views and expectations about learning support. It does not establish that Land Grand improves knowledge. Such a claim requires a defined evaluation method and actual results.

## BIBLIOGRAPHY

This section lists the sources cited in Chapter I.

Department of Education. (2020, July 21). Suggested strategies in implementing distance learning delivery modalities (DLDM) for school year 2020-2021 (DM-CI-2020-00162). Office of the Undersecretary for Curriculum and Instruction.  
https://region8.deped.gov.ph/wp-content/uploads/2020/07/DM-CI-2020-00162-2.pdf

DOST-PHIVOLCS. (2026, June 8). Tsunami information No. 2: Cancellation of tsunami warning.  
https://tsunami.phivolcs.dost.gov.ph/Tsunami_Information/2026_Tsunami_Information/Jun/07/20260607_2337z_Advisory2_2.pdf

UNESCO. (2023). Global education monitoring report 2023: Technology in education: A tool on whose terms?  
https://www.unesco.org/gem-report/en/publication/technology
