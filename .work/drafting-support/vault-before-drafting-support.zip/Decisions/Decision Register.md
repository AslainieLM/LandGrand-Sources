---
type: decisions
status: active
updated: 2026-10-24
---

# Decision Register

## Confirmed decisions

| ID | Date | Decision | Evidence | Affected notes |
| --- | --- | --- | --- | --- |
| D-001 | 2026-10-24 | Use the existing LandGrand Obsidian vault under `D:\Projects\LandGrand-Sources\LandGrand` as the source of truth for the capstone's documented knowledge. Review the supplied pre-proposal as source material. | User instruction in the setup conversation on this date. | [[Home]], [[Maintenance/Vault Guide|Vault Guide]] |
| D-002 | 2026-10-24 | Use the supplied BSIT manuscript PDF for the table-of-contents structure, the Chapter 1–3 lecture deck for writing guidance, and Chapter1.docx as the user’s discussion notes. | User instruction in the reference-import conversation on this date. | [[Manuscript/Table of Contents|Table of Contents]], [[Manuscript/Chapter 1-3 Writing Guide|Writing Guide]] |
| D-003 | 2026-10-24 | Add nature-polishing, nature-shared, and writing-clearly-and-concisely as writing tools for grammar and sentence editing. | User supplied the two GitHub skill-install commands and requested these writing skills. | [[Manuscript/Chapter 1-3 Writing Guide#Language editing skills|Language editing skills]] |
| D-004 | 2026-10-24 | Add a skill guide to the source vault and have agents select applicable skills from ordinary feature requests and other LandGrand scenarios, asking focused questions where the intended outcome is unclear. | User request invoking ask-matt in the skill-routing conversation. | [[Maintenance/Skill Guide|Skill Guide]], [[Home]] |
| D-005 | 2026-10-24 | Use caveman for concise chat responses in this session and record it as the LandGrand communication preference to reduce unnecessary response tokens. Preserve normal artifact prose and honor later requests to change the style. | User explicitly requested /caveman and its inclusion in the vault. | [[Maintenance/Skill Guide#Communication and token use|Communication and token use]] |
| D-006 | 2026-10-24 | Prioritize drafting Land Grand Chapters I–III for now. Retain the project/vault improvement recommendations for later sessions rather than making them the current task. | User stated the manuscript focus and requested that it be stored in the vault for future sessions. | [[Current Focus]], [[Home]] |

The imported proposal is an initial documentary baseline. D-001 does not approve its game rules, research design, or Android range. There are no confirmed resolutions yet for [[Questions/Open Questions|Q-01 through Q-08]].

## Recording a decision

Use [[Templates/Decision|the decision template]] for a change with meaningful rationale or trade-offs. A small clarification can be recorded directly in this register. Include the actual answer, date, who confirmed it, evidence, affected requirements, and any superseded decision. A drafted note remains `proposed` until confirmation exists. Update the canonical note in the same change and link the source or decision beside the changed claim.
