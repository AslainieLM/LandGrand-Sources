---
type: research
status: proposal-baseline
updated: 2026-10-24
sources:
  - "[[Sources/Pre-proposal]]"
---

# Research and Evaluation

## What the proposal establishes

The intended study concerns Grade 5 learners at Baluan Elementary School and aims to improve understanding of landforms, rocks, and minerals through the proposed game. At-home use supplements printed school materials.

Evidence: [[Sources/Pre-proposal Extract#Project Title|Title]], [[Sources/Pre-proposal Extract#Scope of the Study|Scope]], and [[Sources/Pre-proposal Extract#Limitations of the Study|Limitations]].

## What remains undocumented

The supplied pre-proposal does not specify a research design, participant count, recruitment method, instruments, baseline or follow-up measures, study duration, analysis method, evaluation results, or permissions and consent arrangements. No claim of effectiveness can currently be supported by this source.

[[Questions/Open Questions|Q-05]] tracks the evaluation design. Record a confirmed method and instrument evidence here when available. Any later assessment method must be reconciled with the proposal's exclusion of **separate in-game quiz screens**; that exclusion alone does not define a research assessment method.

## Evidence to retain

Keep dated versions of the approved protocol, instruments, relevant school/adviser approvals, and analysis artifacts with source notes. Record the build version and learning content version used in an evaluation so results can be traced to the evaluated game. Summarize results only after actual evidence is supplied.
