---
type: manuscript-dashboard
status: active
updated: 2026-10-24
sources:
  - "[[Manuscript/Table of Contents]]"
  - "[[Manuscript/Chapter 1-3 Writing Guide]]"
---

# Chapters I–III Drafting Dashboard

Use this as the entry point for the current manuscript work. Read the section board for each draft's current state. Status here covers drafts in this vault, not unseen files elsewhere; adviser approval requires its own evidence.

## Now

- [ ] Draft the Purpose and Description section from the pre-proposal. This can begin without inventing local problem statistics.
- [ ] Assemble evidence for Project Context using [[Manuscript/Evidence Register|Evidence Register]].
- [ ] Record the intended citation style and page formatting when confirmed; see MW-02 in [[Manuscript/Chapter 1-3 Writing Guide#Clarifications to retain|writing clarifications]].

## Section board

| Chapter and section | Working draft | Status | Next action |
| --- | --- | --- | --- |
| I — Project Context | [[Manuscript/Drafts/Chapter I Introduction#Project Context|Open section]] | Scaffold only; evidence needed | Find credible global/national evidence and actual local observations; use E-01–E-03. |
| I — Purpose and Description | [[Manuscript/Drafts/Chapter I Introduction#Purpose and Description of the Project|Open section]] | Scaffold only; proposal available | Draft the intended function and learning loop; use E-04 and distinguish proposed benefits from results. |
| I — Objectives | [[Manuscript/Drafts/Chapter I Introduction#Objectives of the Project|Open section]] | Scaffold only | Draft a title-aligned general objective; link each specific objective to an evidenced problem. |
| I — Scope and Limitations | [[Manuscript/Drafts/Chapter I Introduction#Scope and Limitations of the Project|Open section]] | Scaffold only; proposal available | Normalize the current boundaries; keep E-09 open rather than choosing an Android range silently. |
| II — Related Literature / Theoretical Background | [[Manuscript/Drafts/Chapter II Review of Related Literature#Related Literature / Theoretical Background|Open section]] | Scaffold only; sources needed | Select and read actual literature and theory sources; use E-06. |
| II — Related Studies | [[Manuscript/Drafts/Chapter II Review of Related Literature#Related Studies|Open section]] | Scaffold only; sources needed | Read and compare real studies or projects; use E-07. |
| III — Technicality of the project | [[Manuscript/Drafts/Chapter III Technical Background#Technicality of the project|Open section]] | Scaffold only; proposal available | Explain the proposed technical approach in paragraphs. |
| III — Details of the technologies to be used | [[Manuscript/Drafts/Chapter III Technical Background#Details of the technologies to be used|Open section]] | Scaffold only; verification needed | Explain declared technologies and verify versions only when claiming actual configuration; use E-08. |
| III — How the project will work | [[Manuscript/Drafts/Chapter III Technical Background#How the project will work|Open section]] | Scaffold only; proposal available | Describe the intended offline flow; label unresolved rules and planned behavior. |

Progress states: **Scaffold only**, **Drafting**, **Needs evidence**, **Ready for user review**, and **Reviewed**. Add a date and the actual draft location when changing a state. Review status requires evidence of the review.

## Next

- Develop the remaining sections in the order the user requests.
- Keep problem/objective alignment in the Chapter I working file and claim/source tracking in Evidence Register.
- Apply grammar and academic polishing after each section's meaning and evidence are stable.
- When producing Word output, use the selected headings, automatic TOC, and the document skill's layout verification.

## Blocked claims and decisions

Local problem and local novelty claims need evidence before being presented as facts. Literature/theory claims need actual sources. MW-01 and MW-02 affect final presentation; retain them while drafting other sections. Q-01 affects the final device-support wording. Detailed scoring and unlocking decisions affect descriptions of those rules, not every manuscript section.

Research evaluation belongs under the supplied Chapter IV structure. For Chapters I–III, describe an intended benefit or objective honestly; do not present invented learning gains or a completed study.

## Review feedback

Record actual user or adviser feedback here, with the reviewer, date, and a traceable source. Link long comments from a session or source note. Record confirmed decisions in the decision register, and mark feedback addressed only after linking the changed passage or review evidence.

| Date and reviewer | Target section | Feedback and source | Action and evidence |
| --- | --- | --- | --- |

## Section readiness check

- [ ] Required heading and discussion guidance followed.
- [ ] Factual claims have a source and locator, or a visible unresolved marker.
- [ ] Proposal intent, discussion recollection, verified facts, and measured results are distinguished.
- [ ] Problems and objectives agree; scope matches the canonical requirements.
- [ ] Terminology and citations are consistent; grammar has been reviewed.
- [ ] User decisions and remaining issues are recorded; no approval is assumed.

The [vault validator](../../tools/validate_vault.py) checks links, configuration syntax, and retained-source integrity. It does not verify scientific claims, manuscript quality, or adviser approval. Run it from the source workspace using the bundled Python runtime. See [[Maintenance/Vault Guide#Validation and recovery|validation and recovery]] for the exact command.
