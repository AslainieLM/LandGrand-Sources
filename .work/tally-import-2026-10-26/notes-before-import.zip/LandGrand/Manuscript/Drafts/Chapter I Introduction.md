---
type: manuscript-draft
status: proposed
updated: 2026-10-24
sources:
  - "[[Manuscript/Table of Contents]]"
  - "[[Manuscript/Chapter 1-3 Writing Guide]]"
  - "[[Sources/Pre-proposal]]"
---

# Chapter I Introduction

> [!todo] Working scaffold
> This file contains the selected headings and drafting prompts. Replace prompts with supported prose as work proceeds. No completed chapter is claimed. [[Manuscript/Drafting Dashboard|Dashboard]] owns progress; [[Manuscript/Evidence Register|Evidence Register]] owns claim/source status.

## Project Context

Introduce the relevant problem, move from global/national context to the actual local situation, explain the rationale, and close with the reason for the proposed study. Use E-01–E-03. The writing guide records the two-page guidance and the unresolved meaning of “at least four problems.”

**Draft prose:** Not started in this vault.

## Purpose and Description of the Project

Explain the proposed game's function, learner experience, relevance, and evidenced distinctiveness using E-04–E-05. Keep proposed benefits distinct from measured results. Introductory paragraphs and discussion details are in the writing guide.

**Draft prose:** Not started in this vault.

## Objectives of the Project

Draft a general objective aligned with the official title, then specific SMART objectives. Derive problems from evidence before claiming corresponding solutions.

### Drafting notes on problem and objective alignment

This planning table is a working aid, not an added required manuscript subsection. Move it out of final chapter prose when preparing a submission.

| Problem ID | Evidence-supported problem and source | Corresponding specific objective | Related requirement or evaluation evidence |
| --- | --- | --- | --- |
| To assign | No problem statement entered yet | To draft after its problem is supported | To link |

**Draft prose:** Not started in this vault.

## Scope and Limitations of the Project

Use [[Project/Scope and Requirements|the canonical scope]] and describe proposed coverage and exclusions accurately. Retain Q-01 for the Android range. Keep unresolved detailed game rules identified rather than silently specifying them.

**Draft prose:** Not started in this vault.
