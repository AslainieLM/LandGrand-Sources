---
type: decisions
status: active
updated: 2026-10-26
---

# Decision Register

## Confirmed decisions

| ID | Date | Decision | Evidence | Affected notes |
| --- | --- | --- | --- | --- |
| D-001 | 2026-10-24 | Use the existing LandGrand Obsidian vault under `D:\Projects\LandGrand-Sources\LandGrand` as the source of truth for the capstone's documented knowledge. Review the supplied pre-proposal as source material. | User instruction in the setup conversation on this date. | [[Home]], [[Maintenance/Vault Guide|Vault Guide]] |
| D-002 | 2026-10-24 | Use the supplied BSIT manuscript PDF for the table-of-contents structure, the Chapter 1–3 lecture deck for writing guidance, and Chapter1.docx as the user’s discussion notes. | User instruction in the reference-import conversation on this date. | [[Manuscript/Table of Contents|Table of Contents]], [[Manuscript/Chapter 1-3 Writing Guide|Writing Guide]] |
| D-003 | 2026-10-24 | Add nature-polishing, nature-shared, and writing-clearly-and-concisely as writing tools for grammar and sentence editing. | User supplied the two GitHub skill-install commands and requested these writing skills. | [[Manuscript/Chapter 1-3 Writing Guide#Language editing skills|Language editing skills]] |
| D-004 | 2026-10-24 | Add a skill guide to the source vault and have agents select applicable skills from ordinary feature requests and other LandGrand scenarios, asking focused questions where the intended outcome is unclear. | User request invoking ask-matt in the skill-routing conversation. | [[Maintenance/Skill Guide|Skill Guide]], [[Home]] |
| D-005 | 2026-10-24 | Use caveman for concise chat responses in this session and record it as the LandGrand communication preference to reduce unnecessary response tokens. Preserve normal artifact prose and honor later requests to change the style. | User explicitly requested /caveman and its inclusion in the vault. | [[Maintenance/Skill Guide#Communication and token use|Communication and token use]] |
| D-006 | 2026-10-24 | Prioritize drafting Land Grand Chapters I–III for now. Retain the project/vault improvement recommendations for later sessions rather than making them the current task. | User stated the manuscript focus and requested that it be stored in the vault for future sessions. | [[Current Focus]], [[Home]] |
| D-007 | 2026-10-24 | Implement the improvements useful for Chapters I–III drafting now: a short skill router, working outlines and progress board, claim/evidence tracking, and maintained vault checks. Keep game development and broader maintenance deferred. | User asked to implement the improvements necessary to make the vault more usable for current drafting. | [[Manuscript/Drafting Dashboard|Drafting Dashboard]], [[Maintenance/Skill Guide|Skill Guide]] |
| D-008 | 2026-10-26 | Retain the user-supplied Tally - Baluan.docx as survey source material in the vault, with a searchable extraction and links to manuscript evidence. Import does not certify the survey method, resolve discrepancies, or approve scope changes. | User supplied the file and requested its addition to the vault on this date. | [[Sources/Baluan Survey Tally|Survey tally]], [[Manuscript/Evidence Register|Evidence Register]], [[Project/Research and Evaluation|Research and Evaluation]] |
| D-009 | 2026-10-26 | Retain CHAPTER I only.docx as the unrevised manuscript source and revise the working Chapter I against the selected guidance and project evidence. Preserve the original and distinguish it from discussion notes. | User supplied the document, identified it as unrevised, and stated that it needs revision under the Chapter I rules and content. | [[Sources/Chapter I Unrevised Draft|Unrevised chapter]], [[Manuscript/Drafts/Chapter I Introduction|Working revision]], [[Manuscript/Chapter I Revision Notes|Revision notes]] |
| D-010 | 2026-10-26 | Record the user-confirmed survey date of July 1, 2026, Grades 1–6 parent/teacher coverage, and current face-to-face classes at Baluan with modular learning as a contingency during disruptions. These are user-provided facts, not independent school documentation. | [[Sources/Project Clarifications 2026-10-26|Direct user reply]] during Chapter I revision. | [[Sources/Baluan Survey Tally|Survey provenance]], [[Project/Overview|Overview]], [[Manuscript/Evidence Register|Evidence Register]] |

The imported proposal is an initial documentary baseline. D-001 does not approve its game rules, research design, or Android range. There are no confirmed resolutions yet for [[Questions/Open Questions|Q-01 through Q-08]].

## Recording a decision

Use [[Templates/Decision|the decision template]] for a change with meaningful rationale or trade-offs. A small clarification can be recorded directly in this register. Include the actual answer, date, who confirmed it, evidence, affected requirements, and any superseded decision. A drafted note remains `proposed` until confirmation exists. Update the canonical note in the same change and link the source or decision beside the changed claim.
