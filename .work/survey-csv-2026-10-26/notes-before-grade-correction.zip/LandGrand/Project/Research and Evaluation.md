---
type: research
status: proposal-baseline
updated: 2026-10-26
sources:
  - "[[Sources/Pre-proposal]]"
  - "[[Sources/Baluan Survey Tally]]"
---

# Research and Evaluation

## What the proposal establishes

The intended study concerns Grade 5 learners at Baluan Elementary School and aims to improve understanding of landforms, rocks, and minerals through the proposed game. At-home use supplements printed school materials.

Evidence: [[Sources/Pre-proposal Extract#Project Title|Title]], [[Sources/Pre-proposal Extract#Scope of the Study|Scope]], and [[Sources/Pre-proposal Extract#Limitations of the Study|Limitations]].

## Supplied local survey tally

[[Sources/Baluan Survey Tally|Tally - Baluan.docx]] was supplied by the user on 2026-10-26. Its parent and teacher closed-question tables each report 20 responses per item. It also contains subject-difficulty rating distributions, descriptive statistics, two charts, and topic-frequency tables. These are aggregate reported responses; individual records were not supplied.

The tally can support a carefully attributed account of local perceptions and willingness to use mobile learning tools for [[Manuscript/Evidence Register|E-03]]. The file itself omits collection date and grade coverage; [[Sources/Project Clarifications 2026-10-26|the user confirmed]] July 1, 2026 and Grades 1–6 coverage. Sampling and underlying records remain undocumented, as does a completed evaluation of Land Grand. Do not treat these cross-grade perceptions as Grade 5-only results, all-school prevalence, or learning gains.

The source record owns the figures and calculation checks. Q-09–Q-10 in [[Questions/Open Questions|Open Questions]] track missing provenance and a mathematics-topic total discrepancy. The supplied questions do not authorize additional game features or alter the proposal scope.

## What remains undocumented

The supplied pre-proposal does not specify a research design, participant count, recruitment method, instruments, baseline or follow-up measures, study duration, analysis method, evaluation results, or permissions and consent arrangements. No claim of effectiveness can currently be supported by the pre-proposal or the supplied perception tally.

[[Questions/Open Questions|Q-05]] tracks the evaluation design. Record a confirmed method and instrument evidence here when available. Any later assessment method must be reconciled with the proposal's exclusion of **separate in-game quiz screens**; that exclusion alone does not define a research assessment method.

## Evidence to retain

Keep dated versions of the approved protocol, instruments, relevant school/adviser approvals, and analysis artifacts with source notes. Record the build version and learning content version used in an evaluation so results can be traced to the evaluated game. Summarize results only after actual evidence is supplied.
