---
type: writing-guide
status: active
updated: 2026-10-24
sources:
  - "[[Sources/Capstone Manuscript BSIT]]"
  - "[[Sources/Chapter 1-3 Guidelines]]"
  - "[[Sources/Chapter1 Discussion Notes]]"
  - "[[Sources/Pre-proposal]]"
---

# Chapter 1–3 Writing Guide

This guide organizes the references selected in D-002 for future Chapter I–III writing. It is a drafting guide, not completed manuscript prose or evidence that the game improves learning.

Start at [[Manuscript/Drafting Dashboard|Drafting Dashboard]] for working drafts and progress. Track factual support in [[Manuscript/Evidence Register|Evidence Register]]. Read the section below that matches the requested work.

## Which source to use

| Need | Source and role |
| --- | --- |
| Manuscript order and section names | [[Manuscript/Table of Contents|Table of Contents]], derived from [[Sources/Capstone Manuscript BSIT|the PDF]] |
| What to discuss in Chapters I–III | [[Sources/Chapter 1-3 Guidelines|The lecture deck]], with slide locators below |
| Discussion-specific Chapter I reminders | [[Sources/Chapter1 Discussion Notes|The user’s notes]], with typed paragraphs distinguished from screenshots |
| LandGrand audience, proposed features, and exclusions | [[Project/Scope and Requirements|The proposal baseline]], with [[Decisions/Decision Register|confirmed changes]] and [[Questions/Open Questions|unresolved choices]] |

The PDF’s subsection names remain the structural baseline. The deck’s “Related Theories” and “Related Projects” explain content to organize under the PDF’s Chapter II headings. No newer source in this set silently changes the game’s scope. If a writing reference or discussion recollection conflicts with another, retain the disagreement and seek a documented clarification.

## Chapter I – Introduction

### Project Context

Lecture guidance: [[Sources/Chapter 1-3 Guidelines Extract#Slide 17|slide 17]] requires at least two pages of presentation and discussion, describing the prevailing problem from a global, national or regional, and local perspective. [[Sources/Chapter 1-3 Guidelines Extract#Slide 18|Slide 18]] calls for a strong justification and a link between the rationale and research problem.

Your typed discussion notes add the following drafting reminders: begin sections with an introductory paragraph; use an inverted-pyramid introduction; move from global to national to local problems; retain problems the proposed project can address; present problems in bullets; and end with urgency and the reason to conduct the study. The notes say “atleast 4 problem.” Its exact counting scope is unresolved below.

Evidence: [[Sources/Chapter1 Discussion Notes Extract#Paragraph 005|paragraph 5]], [[Sources/Chapter1 Discussion Notes Extract#Paragraph 006|paragraph 6]], [[Sources/Chapter1 Discussion Notes Extract#Paragraph 008|paragraph 8]], and [[Sources/Chapter1 Discussion Notes Extract#Paragraph 012|paragraph 12]].

For LandGrand, gather evidence about the relevant learning problem and the local setting before drafting factual claims. [[Project/Overview|The proposal’s stated purpose]] does not establish low scores, learning deficits, prevalence rates, or a proven need at the school. Mark missing evidence rather than inventing it. Check the two-page requirement in the final Word layout, since Markdown cannot establish the submitted page count.

### Purpose and Description of the Project

Explain the project’s function, value, uniqueness, innovation, and relevance, following [[Sources/Chapter 1-3 Guidelines Extract#Slide 19|slide 19]]. Begin with an introductory paragraph as recorded in your notes.

Use [[Project/Game Flow|the proposed game flow]] and [[Project/Scope and Requirements|scope]] for the description. Paragraph 13 of [[Sources/Chapter1 Discussion Notes Extract#Paragraph 013|your notes]] also mentions local non-implementation. Treat that as a claim to investigate, with a source and date, before stating that no similar project exists locally.

### Objectives of the Project

- Start with a general objective parallel to the official project title.
- Derive specific objectives that help realize that general objective.
- Make objectives SMART. The deck’s own expansion is Specific, Measurable, Achievable, Realistic, and Time-bound.

Evidence: [[Sources/Chapter 1-3 Guidelines Extract#Slide 20|slide 20]] and [[Sources/Chapter 1-3 Guidelines Extract#Slide 11|slide 11]].

Your notes add an introductory paragraph, bullet-form objectives, alignment between each stated problem and its corresponding objective, and objectives that can be implemented in the system. Evidence: [[Sources/Chapter1 Discussion Notes Extract#Paragraph 013|paragraph 13]], [[Sources/Chapter1 Discussion Notes Extract#Paragraph 017|paragraph 17]], [[Sources/Chapter1 Discussion Notes Extract#Paragraph 018|paragraph 18]], and [[Sources/Chapter1 Discussion Notes Extract#Paragraph 019|paragraph 19]].

As a drafting aid, make a problem-to-objective table and link each objective to a relevant requirement or documented evaluation plan. This table is a vault recommendation, not an additional required manuscript heading. Avoid committing to measured learning gains before defining the instrument and study method.

### Scope and Limitations of the Project

Explain the deliverables, features, functions, tools, coverage, time frame, and boundaries. The deck distinguishes included work from exclusions in [[Sources/Chapter 1-3 Guidelines Extract#Slide 21|slides 21]] and [[Sources/Chapter 1-3 Guidelines Extract#Slide 22|22]].

Reuse [[Project/Scope and Requirements|the canonical requirement inventory]] rather than making a second independent feature list. Preserve unresolved items, including Android support, star criteria, and completion rules. State a study time frame only when it is supplied and confirmed.

## Chapter II – Review of Related Literature

Retain the PDF’s two sections: **Related Literature / Theoretical Background** and **Related Studies**. The following lecture guidance helps fill them.

### Related Literature / Theoretical Background

Use literature to establish the foundation and inform the research problem, research design, sources, and later comparisons. Select recent, relevant, objective material grounded in original facts or data. The deck sets no fixed publication-year cutoff or exact literature count. Evidence: [[Sources/Chapter 1-3 Guidelines Extract#Slide 23|slides 23–25]], [[Sources/Chapter 1-3 Guidelines Extract#Slide 26|slide 26]], and [[Sources/Chapter 1-3 Guidelines Extract#Slide 27|slides 27–29]].

For theories, outline first, identify an anchor theory, and use supporting theories to elaborate it. Maintain continuity and correct citation/bibliographic entries. Evidence: [[Sources/Chapter 1-3 Guidelines Extract#Slide 30|slides 30–31]]. Select an actual theory only after reading and citing its source; no theory has been selected for LandGrand in the supplied files.

### Related Studies

For related projects or systems, describe each project, maintain continuity, and consider an inventory, comparative matrix, and appropriately attributed screenshots. The deck says to **consider 3–6 related studies/projects**; this is guidance, not a hard minimum stated in the PDF. Evidence: [[Sources/Chapter 1-3 Guidelines Extract#Slide 31|slide 31]].

A useful comparison for this project would examine audience, subject coverage, learning activities, platform, offline behavior, strengths, and gaps. These comparison dimensions are drafting suggestions. Supply real related-study references before writing comparisons or novelty claims.

## Chapter III – Technical Background

The PDF asks for the project’s technicality **in paragraph form**, technologies to be used, and how the project will work. Evidence: [[Sources/Capstone Manuscript BSIT Extract#PDF Page 1|PDF page 1]].

[[Sources/Chapter 1-3 Guidelines Extract#Slide 32|Slide 32]] adds an overview of current hardware/software/network technologies, the technologies for the proposed system, and discussion of hardware, software, peopleware, and network with continuity.

Use [[Project/Technical Baseline|the declared technical baseline]] and [[Project/Game Flow|game flow]] as starting evidence. Distinguish the school’s existing situation, the proposed game, and verified implementation. Describe offline operation accurately; a generic network topic does not imply a server, website, cloud storage, or online account. Describe roles from evidence and avoid inventing an administrator panel. Confirm actual versions and specifications before calling them installed or tested.

Methodology remains **Chapter IV** in both the PDF and deck. Keep a technical explanation of how the game will work distinct from the research and development methodology to be documented there.

## Clarifications to retain

| ID | Open point | Why it matters |
| --- | --- | --- |
| MW-01 | Does “at least four problems” mean four overall, four local problems, or another grouping? | The typed note does not settle how the count applies. |
| MW-02 | What citation style and Word page-format requirements does the adviser require? | The deck mentions footnotes/endnotes and bibliographic correctness; no specific style or complete formatting policy is supplied. |
| MW-03 | What evidence supports the actual local problem and any claim of local novelty? | Discussion recollection alone does not establish conditions at Baluan Elementary School. |
| MW-04 | How should generic Chapter IV network/database-related headings be treated where they do not apply to the offline game? | Preserve the outline while obtaining adviser guidance on applicability. |

Your Zotero reminder appears in [[Sources/Chapter1 Discussion Notes Extract#Paragraph 024|paragraph 24]]. It can support bibliography management; it does not settle MW-02 or request installation.

## Language editing skills

The user requested these installed skills for grammar and sentence editing in D-003:

| Skill | Use |
| --- | --- |
| [writing-clearly-and-concisely](https://github.com/obra/the-elements-of-style/blob/main/skills/writing-clearly-and-concisely/SKILL.md) | Grammar, punctuation, sentence construction, clarity, and concise prose. |
| [nature-polishing](https://github.com/Yuan1z0825/nature-skills/blob/main/skills/nature-polishing/SKILL.md) | Polish existing academic prose while preserving facts, terminology, and evidence boundaries. |
| [nature-shared](https://github.com/Yuan1z0825/nature-skills/blob/main/skills/nature-shared/SKILL.md) | Shared reference dependency used by nature-polishing; load the references it requests. |

All three are installed under `C:\Users\user\.codex\skills`. For LandGrand, use the generic academic profile in nature-polishing. Keep the selected BSIT headings and school-specific writing requirements as the authority for structure and formatting. Language edits must preserve cited facts, numbers, terms, and uncertainty; flag evidence gaps rather than filling them with invented content. Edit working drafts and retain the original source files unchanged.

## Before marking a chapter ready

- Use the selected headings and maintain source locators for writing requirements.
- Check each factual claim against project evidence or an actual cited reference.
- Align problems, objectives, proposed features, and evaluation claims.
- Preserve the canonical scope and clearly flag unresolved choices.
- Check required length and the automatic TOC in the final Word document.

These are drafting checks. Adviser approval, source authenticity, and completion of the manuscript require their own evidence.
